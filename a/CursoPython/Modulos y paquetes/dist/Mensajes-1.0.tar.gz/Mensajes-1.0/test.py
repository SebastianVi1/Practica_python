from mensajes.hola.saludos import *

saludo()
Saludo()