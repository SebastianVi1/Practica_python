from struct import pack
from setuptools import setup

setup(
    name="Mensajes",
    version="1.0",
    author="Sebastian Villarreal",
    author_email= "...",
    url="",
    package=["mensajes", "mensajes.hola"],
    scripts=["test.py"]
)