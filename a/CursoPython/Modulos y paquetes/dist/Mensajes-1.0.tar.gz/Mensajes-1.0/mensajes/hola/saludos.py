def saludo():
    print("Hola, te saluda sebastian villarreal desde saludos.saludar()")

class Saludo:
    def __init__(self):
        print("Hola te saludo desde.__init__")

if __name__ == "__main__":
    saludo()